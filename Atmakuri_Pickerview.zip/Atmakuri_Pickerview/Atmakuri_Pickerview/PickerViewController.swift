//
//  ViewController.swift
//  Atmakuri_Pickerview
//
//  Created by student on 4/1/22.
//

import UIKit
import AVFoundation;

class PickerViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        self.alphabet.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        String(Array(alphabet)[row])
    }
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.char = String(Array(alphabet)[row])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pickWord.delegate = self
        pickWord.dataSource = self
        self.words.append(Word(token:"swift",clue: "An ios Programming language"))
        self.words.append(Word(token:"Dog",clue: "An animal that barks"))
        self.words.append(Word(token:"Delhi",clue: "Capital of India"))
        self.words.append(Word(token:"Hockey",clue: "national game of india"))
        self.words.append(Word(token:"Rajamouli",clue: "Pan India Director"))
        self.words.append(Word(token:"Sundar",clue: "Google CEO"))
        self.words.append(Word(token:"Dhoni",clue: "Cricketer with Jersey No.7"))
        self.words.append(Word(token:"Audi",clue: "Famous Car Compan"))
        self.words.append(Word(token:"ant",clue: "Small animal name"))
        self.words.append(Word(token:"Netaji",clue: "Subash chandrabose Other name"))
        // Do any additional setup after loading the view.
        generateRandom()
    }
    var char = ""
    var k:Int = 0
    var result:String = ""
    var emoji = ["🚁","⛵️","📱","🔧","📹","🥰","👾","💋","🧠","💍","👑","🏖"]
    var words = [Word]()
    let alphabet = "abcdefghijklmnopqrstuvwxyz".uppercased()
    @IBOutlet weak var GussWordLBL: UILabel!
    
    @IBOutlet weak var ClueLBL: UILabel!
    
    @IBOutlet weak var pickWord: UIPickerView!
    
    
    @IBOutlet weak var CheckLBL: UIButton!
    @IBOutlet weak var PlayagainLBL: UIButton!
    
    
    @IBAction func CheckAction(_ sender: UIButton) {
        
        var gussword = Array(self.GussWordLBL.text!)
        let result1 = Array(self.result)
        if(result.uppercased().contains(char))
        {
            AudioServicesPlaySystemSound(SystemSoundID(1010))
            for i in 0..<result.count{
                print("p : \(result1[i])")
                if(String(result1[i]).uppercased() == char){
                    gussword[i] = Character(char)
                }
            }
        }
        else{
            AudioServicesPlaySystemSound(SystemSoundID(1210))
        }
        self.GussWordLBL.text = String(gussword)
        if(GussWordLBL.text! == result.uppercased()){
            let alert = UIAlertController(title: "congratulations", message: "Your Guess is correct", preferredStyle: .alert)
            let action = UIAlertAction(title: "ok", style: .default, handler: nil)
            alert.addAction(action)
            self.present(alert, animated: true, completion: nil)
            self.CheckLBL.isEnabled = false
            self.PlayagainLBL.isEnabled = true
        }
    }
    
    @IBAction func PlayAgainACtion(_ sender: UIButton) {
        generateRandom()
        
    }
    
    func random() ->Int{
        return Int (arc4random_uniform (UInt32(words.count)))
    }
    
    func Gussconvert(){
        var ins = ""
        for _ in result{
            ins += emoji[Int (arc4random_uniform (UInt32(emoji.count)))]
        }
        self.GussWordLBL.text = ins
    }
    
    func generateRandom(){
        k = random()
        self.ClueLBL.text = words[k].clue
        result = words[k].token
        Gussconvert()
        self.CheckLBL.isEnabled = true
        self.PlayagainLBL.isEnabled = false
    }
    
}

struct Word{
    var token: String
    var clue: String
    
    init(token: String, clue: String)
    {
        self.token = token
        self.clue = clue
    }
}
