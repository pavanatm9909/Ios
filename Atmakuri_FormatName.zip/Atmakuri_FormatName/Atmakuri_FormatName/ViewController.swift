//
//  ViewController.swift
//  Atmakuri_FormatName
//
//  Created by Atmakuri,Pavan Kumar on 2/7/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    
    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    
    @IBAction func onClickOfSubmit(_ sender: Any) {
        if  let fname = self.firstNameTextField.text,let lname=self.lastNameTextField.text, !fname.isEmpty, !lname.isEmpty{
            self.displayLabel.text = "\(lname), \(fname)"
            
        }
    }
    
    @IBAction func onClickOfReset(_ sender: Any) {
        self.lastNameTextField.text = ""
        self.firstNameTextField.text = ""
        self.displayLabel.text = ""
        firstNameTextField.becomeFirstResponder()
    }
    
}

