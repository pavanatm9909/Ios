//
//  ViewController.swift
//  Sec05NavigationDemo
//
//  Created by chandra on 3/22/22.
//

import UIKit

class RootVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.backButtonTitle = "Logout"
    }

    @IBOutlet weak var usernameTF: UITextField!
    
    @IBOutlet weak var passwordTF: UITextField!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let identifer = segue.identifier{
            
            switch identifer{
                
            case "menuSegue":
                
                let menuVC = segue.destination as? MenuVC
                
                // prepare
                
                menuVC?.username = self.usernameTF.text!
                
                menuVC?.navigationItem.title = "Hello, \(self.usernameTF.text!)"
                
            default: break
            }
        }
    }
}

