//
//  MenuVC.swift
//  Sec05NavigationDemo
//
//  Created by chandra on 3/22/22.
//

import UIKit
import AVFoundation

class MenuVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Back"
    }
    
    private let prices = [10.50, 7.99, 5.50, 2.99, 5.67, 4.23, 2.99, 1.50]
    
    var username = ""
    
    private var orderTotal = 0.0
    
    @IBAction func animateMenuItem(_ sender: UITapGestureRecognizer) {
        
        UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 0.4, delay: 0, options: .curveEaseInOut, animations: {
            
            sender.view?.transform = CGAffineTransform.identity.scaledBy(x: 1.1, y: 1.1)
        }, completion: {finished in
            
            UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 0.4, delay: 0, options: .curveEaseInOut, animations: {
                
                sender.view?.transform = CGAffineTransform.identity.scaledBy(x: 1.0, y: 1.0)
            }, completion: nil)
        })
        
        let soundID: SystemSoundID = 1201
        AudioServicesPlayAlertSound(soundID)
        
        self.orderTotal += self.prices[sender.view!.tag]
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let identifer = segue.identifier{
            
            switch identifer{
                
            case "orderStatusSegue":
                
                let osVC = segue.destination as? OrderStatusVC
                
                // prepare
                
                osVC?.username = self.username
                
                osVC?.orderTotal = self.orderTotal
                
                osVC?.navigationItem.title = "Order confirmed"
                
            default: break
            }
        }
    }

}
