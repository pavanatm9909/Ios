//
//  OrderStatusVC.swift
//  Sec05NavigationDemo
//
//  Created by chandra on 3/22/22.
//

import UIKit

class OrderStatusVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.messageTF.text = "Thank you \(self.username). Your order total is \(self.orderTotal)"
    }
    
    var username = ""
    var orderTotal = 0.0
    
    @IBOutlet weak var messageTF: UILabel!
    
}
