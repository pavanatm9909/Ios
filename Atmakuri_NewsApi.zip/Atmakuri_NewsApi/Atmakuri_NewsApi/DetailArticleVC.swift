//
//  DetailArticalVC.swift
//  Atmakuri_NewsApi
//
//  Created by student on 4/8/22.
//

import UIKit
import SDWebImage

class DetailArticleVC: UIViewController {

    
    @IBOutlet weak var titleLBL: UILabel!
    
    @IBOutlet weak var thumbnailIV: UIImageView!
    
    @IBOutlet weak var contentTextView: UITextView!
    
    var titleText = ""
    
    var content = ""
    
    var imageUrl = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.titleLBL.text = self.titleText
        
        self.contentTextView.text = self.content
        
        self.thumbnailIV.sd_setImage(with: URL(string: self.imageUrl), placeholderImage: UIImage(systemName: "photo"))
    }

}
