//
//  ViewController.swift
//  Atmakuri_NewsApi
//
//  Created by student on 4/8/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

