//
//  Model.swift
//  Atmakuri_NewsApi
//
//  Created by student on 4/8/22.
//

import Foundation


struct Article: Codable{
    var title: String?
    var author: String?
    var description: String?
    var urlToImage: String?
    var content: String?
}

struct ArticleHealth: Codable{
    var title: String?
    var author: String?
    var description: String?
    var urlToImage: String?
    var content: String?
}

struct Articles: Codable{
    var articles: [Article]
}

struct ArticlesHealth: Codable{
    var articles: [ArticleHealth]
}

struct AppConstants{
    static let url = "https://newsapi.org/v2/top-headlines?country=us&category=sports&apiKey=dfefcca595514fdda345e3c4cef0e45e"
}

struct AppConstantsHealth{
    static let url = "https://newsapi.org/v2/top-headlines?country=us&category=health&apiKey=dfefcca595514fdda345e3c4cef0e45e"
}
