//
//  ArticalHealthCellVCTableViewCell.swift
//  Atmakuri_NewsApi
//
//  Created by student on 4/8/22.
//

import UIKit

class ArticalHealthCellVC: UITableViewCell {
    
    @IBOutlet weak var Imageview: UIImageView!
    
    @IBOutlet weak var titleLable: UILabel!
    
    @IBOutlet weak var descLable: UILabel!
    
    @IBOutlet weak var authorLable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
