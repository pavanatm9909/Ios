//
//  ViewController.swift
//  Atmakuri_SearchApp
//
//  Created by student on 3/21/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.searchBT.isEnabled =  false
        self.previmage.isHidden = true
        self.nextimage.isHidden = true
        self.resetBT.isHidden = true
        self.resultImage.image = UIImage(named: "default")
    }
    
    var arr = [["clock1","clock2","clock3","clock4","clock5"],
               ["place1","place2","place3","place4","place5"],
               ["animal1","animal2","animal3","animal4","animal5"]]
    
    var clock_keywords = ["clock","watch","time","timer"]
    var places_keywords = ["nature","location","area","place","site"]
    var animals_keywords = ["pets","wild","birls","animal","fish"]
    var topicInfo_arr = [[" worlds oldest surviving working clock is the faceless clock dating from 1386, or possibly earlier, at Salisbury Cathedral, Wiltshire, UK. It was restored in 1956, having struck the hours for 498 years and ticked more than 500 million times.","The most expensive watch ever sold at auction worldwide is the Patek Philippe Grandmaster Chime Ref. 6300A-010, which fetched 31.19 million US dollars (31,000,000 CHF) in Geneva on November 9, 2019 ","The most expensive wristwatch is said to be worth $55 million and is called The Hallucination. Designed and made by Graff Diamonds, it features 110 carats of diamonds in a variety of colours, all set into a platinum bracelet.","After several decades of watchmaking and gaining an international reputation as the preeminent makes of the most precise watches known to man, Zenith began selling in India as early as 1901. Mahatma Gandhi himself was given a Zenith pocket watch by his friend Jawaharlal_Nehru, India's Prime Minister from 1947 to 1964.","These 'clock-watches' were fastened to clothing or worn on a chain around the neck. They were heavy drum-shaped cylindrical brass boxes several inches in diameter, engraved and ornamented."],
               ["To experience some of the most inspiring views America has to offer, plan a trip to Grand Canyon National Park. The Colorado River weaves its way through the 277-mile-long canyon, making it a top destination for whitewater rafting. ","A vacation at Yosemite National Park in California is all about reconnecting with nature. Spend your visit checking out famous landmarks like Half Dome and Glacier Point or hiking Cathedral Lakes, the Mist Trail and other popular paths. ","America's first national park provides more than 900 miles of hiking trails, as well as plenty of attractions to excite nature lovers, from steaming geysers to bubbling hot springs. Plus, animal fans will appreciate a visit to the Grizzly & Wolf Discovery Center to learn about local wildlife.","With idyllic beaches and verdant parks, Maui offers ample opportunities to relax. Here, you can spend your days admiring the scenery as you cruise along the Road to Hana, fly above the Hawaiian island in a helicopter or lounge across the black sands of Waianapanapa State Park","Glaciers are the main draw of this Montana national park, but its more than 700 lakes, two mountain ranges and multiple waterfalls are equally impressive. Hiking is the most popular pastime for visitors thanks to the park's mix of easy trails like Rocky Point and challenging routes, such as Grinnell Glacier and the Highline Trail."],
               ["Due to their status as a delicacy in China and Vietnam, and the belief that their scales have medicinal powers, All four Asian species of pangolin are currently listed as endangered or critically endangered, says Ian Britton, who works in animal rescue in Namibia for REST Namibia and runs the Pangolin & Co. Instagram.","The Seneca white deer are an extremely rare herd of deer who are leucitic, meaning they lack pigmentation in their body, but still have brown eyes. Due to their limited number—there are about 300 in total—the species was given a protected space at the former Seneca Army Depot, where they are free from predators and open to the public to view.","One of my favorite [creatures] says Chris Riley, owner of travel site DaringPlanet.com, is the elephant shrew—or, if you go by its proper name, the Boni Giant Sengi. Indigenous to  the Boni Dodori forest in Kenya, he explains, the elephant shrew has a very unusual appearance, with the body of a mouse and the head of a miniaturized anteater.","While you may have seen a wombat at your local zoo, odds are you've never set sights on this furry fella. Born with spectacularly poor eye sight, these cute critters use their noses to search for food in the darkness. All in all, Radin explains, there are only about 115 left in the wild, all of which are found in Queensland, Australia.","The black-spotted cuscus is a frightening-looking little bugger, with vertical pupils and arched front claws. Only found in New Guinea, the cuscus has sadly been driven to the brink of extinction due to hunting pressures and deforestation. "]]
    
    var topic = -1
    var count1 = 0
    @IBOutlet weak var searchBT: UIButton!
    
    @IBOutlet weak var resetBT: UIButton!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var previmage: UIButton!
    
    @IBOutlet weak var nextimage: UIButton!
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBAction func searchBTEnable(_ sender: UITextField) {
        self.searchBT.isEnabled =  true
    }
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        searchTextField.resignFirstResponder()
        if(clock_keywords.contains(searchTextField.text!)){
            topic = 0
            count1 = 0
        }
        else if(places_keywords.contains(searchTextField.text!)){
            topic = 1
            count1 = 0
        }
        else if(animals_keywords.contains(searchTextField.text!)){
            topic = 2
            count1 = 0
        }
        else{
            resultImage.image = UIImage(named: "notfound")
            topic = -1
            self.topicInfoText.text = ""
            self.previmage.isHidden = true
            self.nextimage.isHidden = true
            self.resetBT.isHidden = true
            
        }
        
        if(topic != -1)
        {
            resultImage.image = UIImage(named: arr[topic][count1])
            topicInfoText.text = topicInfo_arr[topic][count1]
            self.previmage.isHidden = false
            self.nextimage.isHidden = false
            self.previmage.isEnabled = false
            self.nextimage.isEnabled = true
            self.resetBT.isHidden = false
            
        }
        
    }
    
    @IBAction func showNextImage(_ sender: UIButton) {
        self.previmage.isEnabled = true
        count1 += 1
        resultImage.image = UIImage(named: arr[topic][count1])
        topicInfoText.text = topicInfo_arr[topic][count1]
        if(count1 == (arr[topic].count)-1){
            self.nextimage.isEnabled = false
        }
        
    }
    
    @IBAction func ShowPreviousImage(_ sender: UIButton) {
        count1 -= 1
        resultImage.image = UIImage(named: arr[topic][count1])
        topicInfoText.text = topicInfo_arr[topic][count1]
        self.nextimage.isEnabled = true
        if(count1 == 0){
            self.previmage.isEnabled = false
        }
    }
    
    
    @IBAction func reset(_ sender: UIButton) {
        self.searchTextField.text = ""
        self.topicInfoText.text = ""
        self.searchBT.isEnabled =  false
        self.previmage.isHidden = true
        self.nextimage.isHidden = true
        self.resetBT.isHidden = true
        self.resultImage.image = UIImage(named: "default")
    }
    
    
}

