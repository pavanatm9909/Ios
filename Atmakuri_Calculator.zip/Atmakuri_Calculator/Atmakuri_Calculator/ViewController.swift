 //
//  ViewController.swift
//  Atmakuri_Calculator
//
//  Created by student on 2/25/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ResultLBL.text = "0"
    }
    var t1: Double = 0
    var t2:Double = 0
    var op: String = ""

   
    
    @IBOutlet weak var ResultLBL: UILabel!
    
    @IBAction func Opt1(_ sender: UIButton) {
        valuecon(r: ResultLBL.text!, i: "1")
    }
    @IBAction func plusminus(_ sender: UIButton) {
        if(Int(ResultLBL.text!)! > 0 )
        {
            ResultLBL.text = "-"+ResultLBL.text!
        }
        else
        {
            let st: String = ResultLBL.text!
            ResultLBL.text = String(st[st.index(after: st.startIndex) ..< st.endIndex])
        }
    }
    
    @IBAction func Opt2(_ sender: UIButton){
        valuecon(r: ResultLBL.text!, i: "2")
    }
    @IBAction func Opt3(_ sender: UIButton){
        valuecon(r: ResultLBL.text!, i: "3")
    }
    @IBAction func Opt4(_ sender: UIButton){
        valuecon(r: ResultLBL.text!, i: "4")
    }
    @IBAction func Opt5(_ sender: UIButton){
        valuecon(r: ResultLBL.text!, i: "5")
    }
    @IBAction func Opt6(_ sender: UIButton){
        valuecon(r: ResultLBL.text!, i: "6")
    }
    @IBAction func Opt7(_ sender: UIButton){
        valuecon(r: ResultLBL.text!, i: "7")
    }
    @IBAction func Opt8(_ sender: UIButton){
        valuecon(r: ResultLBL.text!, i: "8")
    }
    @IBAction func Opt9(_ sender: UIButton){
        valuecon(r: ResultLBL.text!, i: "9")
    }
    @IBAction func Opt0(_ sender: UIButton){
        valuecon(r: ResultLBL.text!, i: "0")
    }
    @IBAction func AC(_ sender: UIButton){
        ResultLBL.text = ""
        t1 = 0
        t2 = 0
        op = ""
        
    }
    @IBAction func OptC(_ sender: UIButton){
        ResultLBL.text = "0"
        
    }
    @IBAction func OptPlus(_ sender: UIButton){
        bonus2(tt1: t1, tt2: Double(ResultLBL.text!)!, opt1: op)
        op = "+"
        ResultLBL.text = ""
    }
    @IBAction func OptMinus(_ sender: UIButton){
        if(ResultLBL.text! == "0" || ResultLBL.text! == "")
        {
            valuecon(r: ResultLBL.text!, i: "-")
        }
        else
        {
            bonus2(tt1: t1, tt2: Double(ResultLBL.text!)!, opt1: op)
            op = "-"
        ResultLBL.text = ""
        }
    }
    @IBAction func OptMult(_ sender: UIButton){
        bonus2(tt1: t1, tt2: Double(ResultLBL.text!)!, opt1: op)
        op = "*"
        ResultLBL.text = ""
    }
    @IBAction func Optdiv(_ sender: UIButton){
        bonus2(tt1: t1, tt2: Double(ResultLBL.text!)!, opt1: op)
        op = "/"
        ResultLBL.text = ""
    }
    
    @IBAction func optEqual(_ sender: UIButton) {
        var st = ResultLBL.text!
        if(st[st.startIndex] == "√")
        {
            st = String(st[st.index(after: st.startIndex)..<st.endIndex])
        }
        t2 = Double(st)!
        switch op {
        case "+":
            t1 = t1+t2
            valueCon(val1: t1)
            op = ""
        case "-":
            t1 = t1-t2
            valueCon(val1: t1)
            op = ""
        case "/":
            if(t2 == 0)
            {
                ResultLBL.text = "Error"
            }
            else{
                t1 = t1/t2
                valueCon(val1: t1)
                op = ""
                
            }
        case "*":
            t1 = t1*t2
            valueCon(val1: t1)
            op = ""
        case "√":
            t1 = sqrt(Double(t2))
            valueCon(val1: t1)
        default:
            ResultLBL.text = "Error"
        }
        
    }
    
   
    @IBAction func squrBtn(_ sender: UIButton) {
        op = "√"
        ResultLBL.text = "√";
        
    }
    func valuecon(r: String,i: String)
    {
        if(r == "0" || r == "")
        {
            ResultLBL.text = i;
        }
        else
        {
            ResultLBL.text! += i;
        }
    }
    
    func bonus2(tt1: Double, tt2: Double,opt1: String)
    {
        if(tt1 == 0 && opt1 == "")
        {
            t1 = tt2
            
        }
        else{
            
            switch opt1 {
            case "+":
                t1 = tt1+tt2
            case "-":
                t1 = tt1-tt2
            case "/":
                if(t2 == 0)
                {
                    ResultLBL.text = "Error"
                }
                else{
                    t1 = tt1/tt2
                    
                }
            case "*":
                t1 = tt1*tt2
            default:
                ResultLBL.text = "Error"
            }
            
        }
        valueCon(val1: t1)
        
    }
    
    func valueCon(val1: Double)
    {
        if(val1.truncatingRemainder(dividingBy: 1) == 0.0)
        {
            ResultLBL.text = String(Int(val1))
        }
        else{
            
            ResultLBL.text = String(round(val1*100000.0)/100000.0)
        }
    }
    


    
}

