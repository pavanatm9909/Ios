//
//  GalleryVC.swift
//  Atmakuri_NavigationApp
//
//  Created by student on 4/5/22.
//

import UIKit

class GalleryVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tapimage()

        // Do any additional setup after loading the view.
    }
    
   
    
    let imgArray = ["img1","img2","img3","img4","img5","img6","img7","img8"]
    let descArray = ["The Seneca white deer are an extremely rare herd of deer who are leucitic, meaning they lack pigmentation in their body, but still have brown eyes. Due to their limited number—there are about 300 in total—the species was given a protected space at the former Seneca Army Depot, where they are free from predators and open to the public to view.","he black-spotted cuscus is a frightening-looking little bugger, with vertical pupils and arched front claws. Only found in New Guinea, the cuscus has sadly been driven to the brink of extinction due to hunting pressures and deforestation.","The most expensive watch ever sold at auction worldwide is the Patek Philippe Grandmaster Chime Ref. 6300A-010, which fetched 31.19 million US dollars (31,000,000 CHF) in Geneva on November 9, 2019","The most expensive wristwatch is said to be worth $55 million and is called The Hallucination. Designed and made by Graff Diamonds, it features 110 carats of diamonds in a variety of colours, all set into a platinum bracelet.","These 'clock-watches' were fastened to clothing or worn on a chain around the neck. They were heavy drum-shaped cylindrical brass boxes several inches in diameter, engraved and ornamented.","To experience some of the most inspiring views America has to offer, plan a trip to Grand Canyon National Park. The Colorado River weaves its way through the 277-mile-long canyon, making it a top destination for whitewater rafting.","With idyllic beaches and verdant parks, Maui offers ample opportunities to relax. Here, you can spend your days admiring the scenery as you cruise along the Road to Hana, fly above the Hawaiian island in a helicopter or lounge across the black sands of Waianapanapa State Park","Glaciers are the main draw of this Montana national park, but its more than 700 lakes, two mountain ranges and multiple waterfalls are equally impressive. Hiking is the most popular pastime for visitors thanks to the park's mix of easy trails like Rocky Point and challenging routes, such as Grinnell Glacier and the Highline Trail."]
    
    @IBOutlet weak var pic01: UIImageView!
    
    @IBOutlet weak var pic02: UIImageView!
    
    @IBOutlet weak var pic03: UIImageView!
    @IBOutlet weak var pic04: UIImageView!
    
    @IBOutlet weak var pic05: UIImageView!
    
    @IBOutlet weak var pic06: UIImageView!
    
    @IBOutlet weak var pic07: UIImageView!
    
    @IBOutlet weak var pic08: UIImageView!
    
    var tapvalue = 0
    

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let desc = segue.identifier{
            switch desc{
            case "imageDeets":
                
                if let destination = segue.destination as? ImageDescVC{
                    
                    destination.imgval = imgArray[tapvalue]
                    destination.desc = descArray[tapvalue]
                }
                break
            default:
                break
            }
           
        }
    }
    @objc func TapLabel(_ sender: UITapGestureRecognizer) {
            print("TapLabel")
        }
    func tapimage(){
        let imageTap = UITapGestureRecognizer(target: self, action: #selector(self.TapLabel(_:)))
        self.pic01.isUserInteractionEnabled = true
        self.pic01.addGestureRecognizer(imageTap)
        self.pic02.isUserInteractionEnabled = true
        self.pic02.addGestureRecognizer(imageTap)
        self.pic03.isUserInteractionEnabled = true
        self.pic03.addGestureRecognizer(imageTap)
        self.pic04.isUserInteractionEnabled = true
        self.pic04.addGestureRecognizer(imageTap)
        self.pic05.isUserInteractionEnabled = true
        self.pic05.addGestureRecognizer(imageTap)
        self.pic06.isUserInteractionEnabled = true
        self.pic06.addGestureRecognizer(imageTap)
        self.pic07.isUserInteractionEnabled = true
        self.pic07.addGestureRecognizer(imageTap)
        self.pic08.isUserInteractionEnabled = true
        self.pic08.addGestureRecognizer(imageTap)
        
    }
    
    @IBAction func image1(_ sender: UITapGestureRecognizer) {
        self.tapvalue = pic01.tag
        self.performSegue(withIdentifier: "imageDeets", sender: self)
    }
    @IBAction func image2(_ sender: UITapGestureRecognizer) {
        self.tapvalue = pic02.tag
        self.performSegue(withIdentifier: "imageDeets", sender: self)
    }
    @IBAction func image3(_ sender: UITapGestureRecognizer) {
        self.tapvalue = pic03.tag
        self.performSegue(withIdentifier: "imageDeets", sender: self)
    }
    @IBAction func image4(_ sender: UITapGestureRecognizer) {
        self.tapvalue = pic04.tag
        self.performSegue(withIdentifier: "imageDeets", sender: self)
    }
    
    @IBAction func image5(_ sender: UITapGestureRecognizer) {
        self.tapvalue = pic05.tag
        self.performSegue(withIdentifier: "imageDeets", sender: self)
    }
    @IBAction func image6(_ sender: UITapGestureRecognizer) {
        self.tapvalue = pic06.tag
        self.performSegue(withIdentifier: "imageDeets", sender: self)
    }
    @IBAction func image7(_ sender: UITapGestureRecognizer) {
        self.tapvalue = pic07.tag
        self.performSegue(withIdentifier: "imageDeets", sender: self)
    }
    @IBAction func image8(_ sender: UITapGestureRecognizer) {
        print("hello")
        self.tapvalue = pic08.tag
        self.performSegue(withIdentifier: "imageDeets", sender: self)
    }
    
    
 

}
