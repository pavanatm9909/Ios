//
//  HomeVC.swift
//  Atmakuri_ResumeApp
//
//  Created by student on 4/10/22.
//

import UIKit

class HomeVC: UIViewController {
    
    
    @IBOutlet weak var profileIMG: UIImageView!
    
    @IBOutlet weak var nameLBL: UILabel!
    
    @IBOutlet weak var phoneLBL: UILabel!
    
    @IBOutlet weak var emailLBL: UILabel!
    
    @IBOutlet weak var bioTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.nameLBL.text = "Pavan Kumar Atamkuri"
        self.emailLBL.text = "atmakuri.pavan9909@gmail.com"
        self.phoneLBL.text = "+1 4699289722"
        self.bioTextView.text = "HOWDY Folks, MY NAME IS PAVAN KUMAR I'm a Web Designer,Developer,Micro Artist,Enterprenuer. I DO WEBSITES AND PROJECTS AS PER YOUR COMPANY OR BUISNESS NEEDS AND I CUSTOMISE EACH AND EVERY PROJECT THAT ENDEAVOURS TO BETTER, FASTER, EASIER AND MOST ATTRACTIVE. IN SHORT, I seek perfection, and anything that doesn’t move us closer to this feels like a compromise. I pour energy into each detail of a design"
        self.profileIMG.image = UIImage(named: "mypic")
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
