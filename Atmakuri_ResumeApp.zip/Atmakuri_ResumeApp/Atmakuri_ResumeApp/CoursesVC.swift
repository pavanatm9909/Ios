//
//  CoursesVC.swift
//  Atmakuri_ResumeApp
//
//  Created by student on 4/10/22.
//

import UIKit

class CoursesVC: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var CourseTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.CourseTableView.dataSource = self
        self.CourseTableView.delegate = self
        // Do any additional setup after loading the view.
    }
    var DegreebyCourses: [Course] = []
    
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        DegreebyCourses.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        50.0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let courseArticle = self.DegreebyCourses[indexPath.row]
        if let courseCell = cell as? CourseTVCell{
            if let Cname = courseArticle.CourseName{
                courseCell.CourseNameLBL.text = Cname
            }
            if let CGrade = courseArticle.CourseGrade{
                courseCell.CourseGradeLBL.text = "Final Grade : \(CGrade)"
            }
        }
        return cell
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
