//
//  ProjectsVC.swift
//  Atmakuri_ResumeApp
//
//  Created by student on 4/10/22.
//

import UIKit

class ProjectsVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    
    
    @IBOutlet weak var projectsTableView: UITableView!
    
    var projects = [Project]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.projectsTableView.dataSource = self
        self.projectsTableView.delegate = self
        projects.append(Project(projectName: "EKart", projectDescription: "This application having two types of login, Based upon login type the application will display in front end. If it is Distributor login he can access the probucts to adding, remove and adding DealsOfDay. If it is customer Login they can buy a products and adding to the cart"))
        projects.append(Project(projectName: "Disciplinary Committee Management", projectDescription: "It stores the information of the student who are not came with dress code and transfer that data through admin, and providing the result in statics way for each month."))
        projects.append(Project(projectName: "Zoo Restaurant", projectDescription: "This application will helps for self check-in and self ordering the food in zoo park"))
        projects.append(Project(projectName: "Super Market Billing System", projectDescription: "Supermarket is the place where customers come to purchase their daily using products and pay for that. So there is a need to calculate how many products are sold and to generate the bill for the customer."))
        projects.append(Project(projectName: "Booking Train Ticket", projectDescription: "In this project, we are displaying the train details for a passenger who is trying to book a ticket such as time, destination, categorys and then after booking a ticket we are displaying the Travel Details and fare which he had provided for booking a ticket."))
        projects.append(Project(projectName: "My own web site", projectDescription: "This is my own web site crated using frond end technologies. This web site is about my self."))

        // Do any additional setup after loading the view.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        projects.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        70.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let project = self.projects[indexPath.row]
        if let projectCell = cell as? ProjectTVCell{
            if let Pname = project.projectName{
                projectCell.projectNameLBL.text = Pname
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "projectsSegue", sender: indexPath)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let identifier = segue.identifier{
            switch identifier{
                
            case "projectsSegue":
                if let destinationVC = segue.destination as? ProjectDescVC {
                    if let ip = sender as? IndexPath{
                        let project = self.projects[ip.row]
                        
                        if let proName = project.projectName{
                            destinationVC.pname = proName
                        }
                        
                        if let proDesc = project.projectDescription{
                            destinationVC.desc = proDesc
                        }
                    }
                }
            default: break
            }
            
        }
        
    }

}
