//
//  CourseTVCell.swift
//  Atmakuri_ResumeApp
//
//  Created by student on 4/10/22.
//

import UIKit

class CourseTVCell: UITableViewCell {
    
    
    @IBOutlet weak var CourseNameLBL: UILabel!
    
    @IBOutlet weak var CourseGradeLBL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
