//
//  DegreeTVCell.swift
//  Atmakuri_ResumeApp
//
//  Created by student on 4/10/22.
//

import UIKit

class DegreeTVCell: UITableViewCell {
    
    
    @IBOutlet weak var DegreenameLBL: UILabel!
    
    @IBOutlet weak var UniversitynameLBL: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
