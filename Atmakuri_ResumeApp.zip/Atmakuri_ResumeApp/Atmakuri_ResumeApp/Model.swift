//
//  Model.swift
//  Atmakuri_ResumeApp
//
//  Created by student on 4/10/22.
//

import Foundation

struct Degree{
    var DegreeNames: String?
    var universityName: String?
    var courses: [Course]
    
    init(DegreeName: String?,universityName: String?, courses: [Course]){
        self.DegreeNames = DegreeName
        self.universityName = universityName
        self.courses = courses
    }
}

struct Course{
    var CourseName: String?
    var CourseGrade: String?
    init(CourseName: String,CourseGrade: String){
        self.CourseName = CourseName
        self.CourseGrade = CourseGrade
    }
    
}

struct Project{
    var projectName : String?
    var projectDescription : String?
    init(projectName :String, projectDescription: String){
        self.projectName = projectName
        self.projectDescription = projectDescription
    }
}
