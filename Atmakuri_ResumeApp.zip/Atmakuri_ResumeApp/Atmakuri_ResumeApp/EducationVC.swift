//
//  EducationVC.swift
//  Atmakuri_ResumeApp
//
//  Created by student on 4/10/22.
//

import UIKit

class EducationVC: UIViewController,UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var DegreeTableView: UITableView!
    var degree = [Degree]()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.DegreeTableView.dataSource = self
        self.DegreeTableView.delegate = self
        self.degree.append(Degree(DegreeName: "M.S in Appled Computer Science - 2022", universityName: "Northwest Missouri State universith with 4.0", courses: [Course(CourseName: "Mobile Computing-ios-Spring 2022", CourseGrade: "A"),Course(CourseName: "OOPS Programing - fall 2021", CourseGrade: "A"),Course(CourseName: "Project Managment - Spring 2022", CourseGrade: "A"),Course(CourseName: "ADV Topics inDB System - fall 2021", CourseGrade: "A"),Course(CourseName: "Devel web Apps -fall 2021", CourseGrade: "A")]))
        self.degree.append(Degree(DegreeName: "BTECH in Computer Science 2020", universityName: "KL University with 8.4gpa", courses: [Course(CourseName: "C Programing", CourseGrade: "A"),Course(CourseName: "Network Computing ", CourseGrade: "A"),Course(CourseName: "Data Structures", CourseGrade: "A"),Course(CourseName: "Single variable caliculus ", CourseGrade: "A"),Course(CourseName: "Engineering Graphics", CourseGrade: "A"),Course(CourseName: "Engineering Chemistry", CourseGrade: "B"),Course(CourseName: "Mesurements", CourseGrade: "B"),Course(CourseName: "Mechanics", CourseGrade: "A"),Course(CourseName: "Multivariate Calculus", CourseGrade: "A"),Course(CourseName: "Software Engineering", CourseGrade: "B"),Course(CourseName: "Digital System Design", CourseGrade: "B"),Course(CourseName: "Discrete Mathematics", CourseGrade: "A"),Course(CourseName: "DataBase System", CourseGrade: "A"),Course(CourseName: "Theory of Computation", CourseGrade: "B"),Course(CourseName: "Coding Skills ", CourseGrade: "A")]))
        // Do any additional setup after loading the view.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        degree.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        80.0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let typeOfDegree = self.degree[indexPath.row]
        if let degreeCell = cell as? DegreeTVCell{
            if let Dname = typeOfDegree.DegreeNames{
                degreeCell.DegreenameLBL.text = Dname
            }
            if let Uname = typeOfDegree.universityName{
                degreeCell.UniversitynameLBL.text = Uname
            }
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "coursesSegue", sender: indexPath)
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let identifier = segue.identifier{
            switch identifier{
                
            case "coursesSegue":
                if let destinationVC = segue.destination as? CoursesVC {
                    if let ip = sender as? IndexPath{
                        destinationVC.DegreebyCourses = self.degree[ip.row].courses
                    }
                }
            default: break
            }
            
        }
        
    }
   

}
